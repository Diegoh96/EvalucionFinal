/*==================================================
                VARIABLES GLOBALES
==================================================*/

const formulario = document.getElementById("formProducto");

const tablaProductos = document.getElementById("tablaProductos");

const buscador = document.getElementById("buscar");

let productos = [];

let editando = false;

let idEditar = null;


/*==================================================
            CARGAR AL INICIAR LA APP
==================================================*/

document.addEventListener("DOMContentLoaded", async () => {

    buscador.value = obtenerBusqueda();

    await cargarProductos();

});


/*==================================================
            OBTENER PRODUCTOS
==================================================*/

async function cargarProductos() {

    productos = await obtenerProductos();

    mostrarProductos(productos);

}


/*==================================================
            MOSTRAR PRODUCTOS
==================================================*/

function mostrarProductos(lista) {

    tablaProductos.innerHTML = "";

    if (lista.length === 0) {

        const fila = document.createElement("tr");

        const columna = document.createElement("td");

        columna.colSpan = 6;

        columna.textContent = "No existen productos.";

        fila.appendChild(columna);

        tablaProductos.appendChild(fila);

        return;

    }

    lista.forEach(producto => {

        crearFila(producto);

    });

}


/*==================================================
            CREAR FILA
==================================================*/

function crearFila(producto) {

    const fila = document.createElement("tr");


    /* ID */

    const tdId = document.createElement("td");

    tdId.textContent = producto.id;


    /* Nombre */

    const tdNombre = document.createElement("td");

    tdNombre.textContent = producto.nombre;


    /* Precio */

    const tdPrecio = document.createElement("td");

    tdPrecio.textContent = "$ " + producto.precio.toLocaleString();


    /* Categoría */

    const tdCategoria = document.createElement("td");

    tdCategoria.textContent = producto.categoria;


    /* Stock */

    const tdStock = document.createElement("td");

    tdStock.textContent = producto.stock;


    /* Acciones */

    const tdAcciones = document.createElement("td");

    const btnEditar = document.createElement("button");

    btnEditar.textContent = "Editar";

    btnEditar.classList.add("editar");

    btnEditar.dataset.id = producto.id;


    const btnEliminar = document.createElement("button");

    btnEliminar.textContent = "Eliminar";

    btnEliminar.classList.add("eliminar");

    btnEliminar.dataset.id = producto.id;


    tdAcciones.appendChild(btnEditar);

    tdAcciones.appendChild(document.createTextNode(" "));

    tdAcciones.appendChild(btnEliminar);


    fila.appendChild(tdId);

    fila.appendChild(tdNombre);

    fila.appendChild(tdPrecio);

    fila.appendChild(tdCategoria);

    fila.appendChild(tdStock);

    fila.appendChild(tdAcciones);


    tablaProductos.appendChild(fila);

}


/*==================================================
                BUSCADOR
==================================================*/

buscador.addEventListener("keyup", () => {

    const texto = buscador.value.toLowerCase();

    guardarBusqueda(texto);

    const filtrados = productos.filter(producto => {

        return (

            producto.nombre.toLowerCase().includes(texto)

            ||

            producto.categoria.toLowerCase().includes(texto)

        );

    });

    mostrarProductos(filtrados);

});


/*==================================================
        LIMPIAR FORMULARIO
==================================================*/

function limpiarFormulario() {

    formulario.reset();

    limpiarErrores();

    editando = false;

    idEditar = null;

}

/*==================================================
        EVENTOS DE LA TABLA (EDITAR / ELIMINAR)
==================================================*/

tablaProductos.addEventListener("click", async (e) => {

    const id = Number(e.target.dataset.id);

    if (!id) return;

    if (e.target.classList.contains("editar")) {

        await cargarFormulario(id);

    }

    if (e.target.classList.contains("eliminar")) {

        await eliminarRegistro(id);

    }

});


/*==================================================
            CARGAR FORMULARIO
==================================================*/

async function cargarFormulario(id) {

    const producto = await obtenerProducto(id);

    if (!producto) {

        alert("Producto no encontrado.");

        return;

    }

    txtNombre.value = producto.nombre;

    txtPrecio.value = producto.precio;

    txtCategoria.value = producto.categoria;

    txtStock.value = producto.stock;

    editando = true;

    idEditar = id;

    formulario.querySelector("button").textContent = "Actualizar Producto";

    txtNombre.focus();

}


/*==================================================
            ELIMINAR REGISTRO
==================================================*/

async function eliminarRegistro(id) {

    const confirmar = confirm(

        "¿Desea eliminar este producto?"

    );

    if (!confirmar) {

        return;

    }

    const eliminado = await eliminarProducto(id);

    if (!eliminado) {

        return;

    }

    alert("Producto eliminado correctamente.");

    await cargarProductos();

}


/*==================================================
        RESTAURAR BOTÓN DEL FORMULARIO
==================================================*/

function restaurarBoton() {

    formulario.querySelector("button").textContent =

        "Guardar Producto";

}


/*==================================================
        LIMPIAR COMPLETAMENTE
==================================================*/

function reiniciarFormulario() {

    formulario.reset();

    limpiarErrores();

    restaurarBoton();

    editando = false;

    idEditar = null;

}


/*==================================================
        ORDENAR PRODUCTOS POR NOMBRE
==================================================*/

function ordenarProductos() {

    productos.sort((a, b) =>

        a.nombre.localeCompare(b.nombre)

    );

}


/*==================================================
        RECARGAR TABLA
==================================================*/

async function refrescarTabla() {

    await cargarProductos();

    ordenarProductos();

    mostrarProductos(productos);

}

/*==================================================
        SUBMIT DEL FORMULARIO
==================================================*/

formulario.addEventListener("submit", async (e) => {

    e.preventDefault();

    if (!validarFormulario()) {

        return;

    }

    const producto = {

        nombre: txtNombre.value.trim(),

        precio: Number(txtPrecio.value),

        categoria: txtCategoria.value,

        stock: Number(txtStock.value)

    };

    let resultado = false;

    if (editando) {

        resultado = await actualizarProducto(

            idEditar,

            producto

        );

        if (resultado) {

            alert("Producto actualizado correctamente.");

        }

    } else {

        resultado = await agregarProducto(producto);

        if (resultado) {

            alert("Producto agregado correctamente.");

        }

    }

    if (!resultado) {

        return;

    }

    reiniciarFormulario();

    await refrescarTabla();

});


/*==================================================
        BOTÓN ENTER EN BUSCADOR
==================================================*/

buscador.addEventListener("keypress", (e) => {

    if (e.key === "Enter") {

        e.preventDefault();

    }

});


/*==================================================
        LIMPIAR BUSCADOR
==================================================*/

function limpiarBuscador() {

    buscador.value = "";

    limpiarBusqueda();

    mostrarProductos(productos);

}


/*==================================================
        RECARGAR AL CAMBIAR VENTANA
==================================================*/

window.addEventListener("focus", async () => {

    await cargarProductos();

});


/*==================================================
        ATAJOS DE TECLADO
==================================================*/

document.addEventListener("keydown", (e) => {

    if (e.key === "Escape") {

        reiniciarFormulario();

    }

});


/*==================================================
        VALIDACIÓN EXTRA
==================================================*/

txtNombre.addEventListener("blur", () => {

    txtNombre.value = txtNombre.value.trim();

});


/*==================================================
        ORDENAR AUTOMÁTICAMENTE
==================================================*/

function ordenarYMostrar() {

    ordenarProductos();

    mostrarProductos(productos);

}


/*==================================================
        ACTUALIZAR TABLA
==================================================*/

async function actualizarVista() {

    productos = await obtenerProductos();

    ordenarYMostrar();

}


/*==================================================
        INICIALIZACIÓN
==================================================*/

(async function iniciarAplicacion(){

    await actualizarVista();

})();