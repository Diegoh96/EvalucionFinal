const URL = "http://localhost:3000/api/productos";

/*==========================
    OBTENER PRODUCTOS
==========================*/

async function obtenerProductos() {

    try {

        const respuesta = await fetch(URL);

        if (!respuesta.ok) {

            throw new Error("Error al obtener productos");

        }

        const datos = await respuesta.json();

        return datos;

    } catch (error) {

        console.error(error);

        return [];

    }

}

/*==========================
    OBTENER PRODUCTO POR ID
==========================*/

async function obtenerProducto(id) {

    try {

        const respuesta = await fetch(`${URL}/${id}`);

        if (!respuesta.ok) {

            throw new Error("Producto no encontrado");

        }

        return await respuesta.json();

    } catch (error) {

        console.error(error);

        return null;

    }

}

/*==========================
      AGREGAR PRODUCTO
==========================*/

async function agregarProducto(producto) {

    try {

        const respuesta = await fetch(URL, {

            method: "POST",

            headers: {

                "Content-Type": "application/json"

            },

            body: JSON.stringify(producto)

        });

        const datos = await respuesta.json();

        if (!respuesta.ok) {

            alert(datos.mensaje);

            return false;

        }

        return true;

    } catch (error) {

        console.error(error);

        return false;

    }

}

/*==========================
      ACTUALIZAR PRODUCTO
==========================*/

async function actualizarProducto(id, producto) {

    try {

        const respuesta = await fetch(`${URL}/${id}`, {

            method: "PUT",

            headers: {

                "Content-Type": "application/json"

            },

            body: JSON.stringify(producto)

        });

        const datos = await respuesta.json();

        if (!respuesta.ok) {

            alert(datos.mensaje);

            return false;

        }

        return true;

    } catch (error) {

        console.error(error);

        return false;

    }

}

/*==========================
      ELIMINAR PRODUCTO
==========================*/

async function eliminarProducto(id) {

    try {

        const respuesta = await fetch(`${URL}/${id}`, {

            method: "DELETE"

        });

        const datos = await respuesta.json();

        if (!respuesta.ok) {

            alert(datos.mensaje);

            return false;

        }

        return true;

    } catch (error) {

        console.error(error);

        return false;

    }

}

/*==========================
    GUARDAR EN LOCALSTORAGE
==========================*/

function guardarBusqueda(texto) {

    localStorage.setItem("busqueda", texto);

}

/*==========================
    OBTENER LOCALSTORAGE
==========================*/

function obtenerBusqueda() {

    return localStorage.getItem("busqueda") || "";

}

/*==========================
      LIMPIAR STORAGE
==========================*/

function limpiarBusqueda() {

    localStorage.removeItem("busqueda");

}