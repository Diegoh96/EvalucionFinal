/*==========================================
            ELEMENTOS DEL FORMULARIO
==========================================*/

const txtNombre = document.getElementById("nombre");

const txtPrecio = document.getElementById("precio");

const txtCategoria = document.getElementById("categoria");

const txtStock = document.getElementById("stock");

/*==========================================
            MENSAJES DE ERROR
==========================================*/

const errorNombre = document.getElementById("errorNombre");

const errorPrecio = document.getElementById("errorPrecio");

const errorCategoria = document.getElementById("errorCategoria");

const errorStock = document.getElementById("errorStock");

/*==========================================
            LIMPIAR ERRORES
==========================================*/

function limpiarErrores() {

    errorNombre.textContent = "";

    errorPrecio.textContent = "";

    errorCategoria.textContent = "";

    errorStock.textContent = "";

    txtNombre.classList.remove("inputError");

    txtPrecio.classList.remove("inputError");

    txtCategoria.classList.remove("inputError");

    txtStock.classList.remove("inputError");

}

/*==========================================
        MOSTRAR ERROR
==========================================*/

function mostrarError(input, elemento, mensaje) {

    elemento.textContent = mensaje;

    input.classList.add("inputError");

}

/*==========================================
        VALIDAR NOMBRE
==========================================*/

function validarNombre() {

    const nombre = txtNombre.value.trim();

    if (nombre === "") {

        mostrarError(

            txtNombre,

            errorNombre,

            "El nombre es obligatorio"

        );

        return false;

    }

    if (nombre.length < 3) {

        mostrarError(

            txtNombre,

            errorNombre,

            "Debe tener al menos 3 caracteres"

        );

        return false;

    }

    return true;

}

/*==========================================
        VALIDAR PRECIO
==========================================*/

function validarPrecio() {

    const precio = Number(txtPrecio.value);

    if (txtPrecio.value === "") {

        mostrarError(

            txtPrecio,

            errorPrecio,

            "Ingrese un precio"

        );

        return false;

    }

    if (isNaN(precio)) {

        mostrarError(

            txtPrecio,

            errorPrecio,

            "Debe ser un número"

        );

        return false;

    }

    if (precio <= 0) {

        mostrarError(

            txtPrecio,

            errorPrecio,

            "Debe ser mayor que cero"

        );

        return false;

    }

    return true;

}

/*==========================================
        VALIDAR CATEGORÍA
==========================================*/

function validarCategoria() {

    if (txtCategoria.value === "") {

        mostrarError(

            txtCategoria,

            errorCategoria,

            "Seleccione una categoría"

        );

        return false;

    }

    return true;

}

/*==========================================
        VALIDAR STOCK
==========================================*/

function validarStock() {

    const stock = Number(txtStock.value);

    if (txtStock.value === "") {

        mostrarError(

            txtStock,

            errorStock,

            "Ingrese el stock"

        );

        return false;

    }

    if (!Number.isInteger(stock)) {

        mostrarError(

            txtStock,

            errorStock,

            "Debe ser un número entero"

        );

        return false;

    }

    if (stock < 0) {

        mostrarError(

            txtStock,

            errorStock,

            "No puede ser negativo"

        );

        return false;

    }

    return true;

}

/*==========================================
        VALIDACIÓN GENERAL
==========================================*/

function validarFormulario() {

    limpiarErrores();

    let valido = true;

    if (!validarNombre()) {

        valido = false;

    }

    if (!validarPrecio()) {

        valido = false;

    }

    if (!validarCategoria()) {

        valido = false;

    }

    if (!validarStock()) {

        valido = false;

    }

    return valido;

}

/*==========================================
        EVENTOS INPUT
==========================================*/

txtNombre.addEventListener("input", validarNombre);

txtPrecio.addEventListener("input", validarPrecio);

txtCategoria.addEventListener("change", validarCategoria);

txtStock.addEventListener("input", validarStock);