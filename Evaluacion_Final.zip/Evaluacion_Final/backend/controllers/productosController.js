const {
    obtenerProductos,
    guardarProductos
} = require("../models/productoModel");

// Listar todos
const listar = (req, res) => {

    const productos = obtenerProductos();

    res.status(200).json(productos);

};

// Obtener uno
const obtener = (req, res) => {

    const id = parseInt(req.params.id);

    const productos = obtenerProductos();

    const producto = productos.find(p => p.id === id);

    if (!producto) {

        return res.status(404).json({
            mensaje: "Producto no encontrado"
        });

    }

    res.json(producto);

};

// Crear
const crear = (req, res) => {

    const productos = obtenerProductos();

    const {
        nombre,
        precio,
        categoria,
        stock
    } = req.body;

    if (!nombre || nombre.trim().length < 3) {

        return res.status(400).json({
            mensaje: "Nombre inválido"
        });

    }

    if (productos.some(p => p.nombre.toLowerCase() === nombre.toLowerCase())) {

        return res.status(400).json({
            mensaje: "Ya existe un producto con ese nombre"
        });

    }

    if (precio <= 0) {

        return res.status(400).json({
            mensaje: "Precio inválido"
        });

    }

    if (!categoria) {

        return res.status(400).json({
            mensaje: "Categoría obligatoria"
        });

    }

    if (stock < 0) {

        return res.status(400).json({
            mensaje: "Stock inválido"
        });

    }

    const nuevo = {

        id: productos.length
            ? productos[productos.length - 1].id + 1
            : 1,

        nombre,

        precio: Number(precio),

        categoria,

        stock: Number(stock)

    };

    productos.push(nuevo);

    guardarProductos(productos);

    res.status(201).json({
        mensaje: "Producto agregado",
        producto: nuevo
    });

};

// Editar
const actualizar = (req, res) => {

    const id = parseInt(req.params.id);

    const productos = obtenerProductos();

    const indice = productos.findIndex(p => p.id === id);

    if (indice === -1) {

        return res.status(404).json({
            mensaje: "Producto no encontrado"
        });

    }

    const {
        nombre,
        precio,
        categoria,
        stock
    } = req.body;

    if (!nombre || nombre.trim().length < 3) {

        return res.status(400).json({
            mensaje: "Nombre inválido"
        });

    }

    if (precio <= 0) {

        return res.status(400).json({
            mensaje: "Precio inválido"
        });

    }

    if (stock < 0) {

        return res.status(400).json({
            mensaje: "Stock inválido"
        });

    }

    productos[indice] = {

        id,

        nombre,

        precio: Number(precio),

        categoria,

        stock: Number(stock)

    };

    guardarProductos(productos);

    res.json({

        mensaje: "Producto actualizado",

        producto: productos[indice]

    });

};

// Eliminar
const eliminar = (req, res) => {

    const id = parseInt(req.params.id);

    const productos = obtenerProductos();

    const nuevos = productos.filter(p => p.id !== id);

    if (productos.length === nuevos.length) {

        return res.status(404).json({
            mensaje: "Producto no encontrado"
        });

    }

    guardarProductos(nuevos);

    res.json({

        mensaje: "Producto eliminado"

    });

};

module.exports = {

    listar,

    obtener,

    crear,

    actualizar,

    eliminar

};