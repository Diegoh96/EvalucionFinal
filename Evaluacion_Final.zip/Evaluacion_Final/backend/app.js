const express = require("express");

const app = express();

const productosRoutes = require("./routes/productos");

app.use(express.json());

app.use(express.urlencoded({
    extended:true
}));

app.use((req,res,next)=>{

    res.header("Access-Control-Allow-Origin","*");

    res.header(
        "Access-Control-Allow-Headers",
        "Origin, X-Requested-With, Content-Type, Accept"
    );

    res.header(
        "Access-Control-Allow-Methods",
        "GET,POST,PUT,DELETE"
    );

    next();

});

app.use("/api/productos",productosRoutes);

const PORT=3000;

app.listen(PORT,()=>{

    console.log("--------------------------------");

    console.log("Servidor iniciado");

    console.log("Puerto:",PORT);

    console.log("http://localhost:"+PORT);

    console.log("--------------------------------");

});