const fs = require("fs");

const path = require("path");

const ruta = path.join(__dirname,"../database/productos.json");

function obtenerProductos(){

    const datos = fs.readFileSync(ruta);

    return JSON.parse(datos);

}

function guardarProductos(productos){

    fs.writeFileSync(
        ruta,
        JSON.stringify(productos,null,2)
    );

}

module.exports = {

    obtenerProductos,

    guardarProductos

};